import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class StudentPanel extends JPanel {
    private MainFrame mainFrame;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;

    private static final String[] COLUMNS = {
        "Student ID", "Name", "Gender", "Course", "Year", "Phone", "Room No.", "Status"
    };

    public StudentPanel(MainFrame mainFrame) {
        this.mainFrame = mainFrame;
        setBackground(AppTheme.BG_MAIN);
        setLayout(new BorderLayout());
        initUI();
    }

    private void initUI() {
        // Header
        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setBackground(AppTheme.BG_MAIN);
        header.setBorder(new EmptyBorder(28, 32, 16, 32));

        JPanel titlePanel = new JPanel();
        titlePanel.setOpaque(false);
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Student Management");
        title.setFont(AppTheme.FONT_TITLE);
        title.setForeground(AppTheme.TEXT_PRIMARY);
        JLabel sub = new JLabel("Add, view, edit and remove students");
        sub.setFont(AppTheme.FONT_SUBTITLE);
        sub.setForeground(AppTheme.TEXT_SECONDARY);
        titlePanel.add(title);
        titlePanel.add(sub);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnPanel.setOpaque(false);
        JButton addBtn = makeBtn("➕  Add Student", AppTheme.SUCCESS);
        JButton editBtn = makeBtn("✏️  Edit", AppTheme.PRIMARY);
        JButton delBtn  = makeBtn("🗑  Delete", AppTheme.DANGER);
        JButton deallocBtn = makeBtn("🔓  Deallocate", AppTheme.WARNING);

        addBtn.addActionListener(e -> showStudentDialog(null));
        editBtn.addActionListener(e -> editSelected());
        delBtn.addActionListener(e -> deleteSelected());
        deallocBtn.addActionListener(e -> deallocateSelected());

        btnPanel.add(deallocBtn);
        btnPanel.add(delBtn);
        btnPanel.add(editBtn);
        btnPanel.add(addBtn);

        header.add(titlePanel, BorderLayout.WEST);
        header.add(btnPanel, BorderLayout.EAST);
        add(header, BorderLayout.NORTH);

        // Search bar
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        searchBar.setBackground(AppTheme.BG_MAIN);
        searchBar.setBorder(new EmptyBorder(0, 32, 10, 32));
        searchField = new JTextField(30);
        searchField.setFont(AppTheme.FONT_BODY);
        searchField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AppTheme.BORDER),
            BorderFactory.createEmptyBorder(6, 12, 6, 12)));
        searchField.putClientProperty("JTextField.placeholderText", "Search by name, ID, course...");
        JButton searchBtn = makeBtn("🔍  Search", AppTheme.INFO);
        searchBtn.setPreferredSize(new Dimension(110, 36));
        searchBtn.addActionListener(e -> filterTable());
        searchField.addActionListener(e -> filterTable());
        JButton clearBtn = makeBtn("✕ Clear", AppTheme.GRAY);
        clearBtn.setPreferredSize(new Dimension(90, 36));
        clearBtn.addActionListener(e -> { searchField.setText(""); refresh(); });
        searchBar.add(searchField);
        searchBar.add(Box.createHorizontalStrut(8));
        searchBar.add(searchBtn);
        searchBar.add(Box.createHorizontalStrut(6));
        searchBar.add(clearBtn);
        add(searchBar, BorderLayout.AFTER_LAST_LINE);

        // Table
        tableModel = new DefaultTableModel(COLUMNS, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        styleTable(table);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createCompoundBorder(
            new EmptyBorder(0, 32, 24, 32),
            BorderFactory.createLineBorder(AppTheme.BORDER)));
        scroll.getViewport().setBackground(Color.WHITE);
        add(scroll, BorderLayout.CENTER);

        refresh();
    }

    private void styleTable(JTable t) {
        t.setFont(AppTheme.FONT_TABLE_BODY);
        t.setRowHeight(34);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setSelectionBackground(new Color(220, 232, 255));
        t.setSelectionForeground(AppTheme.TEXT_PRIMARY);
        t.setFocusable(false);

        JTableHeader header = t.getTableHeader();
        header.setFont(AppTheme.FONT_TABLE_HEAD);
        header.setBackground(AppTheme.BG_TABLE_HEADER);
        header.setForeground(AppTheme.TEXT_TABLE_HEAD);
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(0, 38));
        ((DefaultTableCellRenderer) header.getDefaultRenderer()).setHorizontalAlignment(SwingConstants.LEFT);

        t.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean selected,
                    boolean focused, int row, int col) {
                super.getTableCellRendererComponent(table, value, selected, focused, row, col);
                setBorder(new EmptyBorder(0, 14, 0, 8));
                if (!selected) {
                    setBackground(row % 2 == 0 ? Color.WHITE : AppTheme.BG_TABLE_ALT);
                    String status = (String) table.getValueAt(row, 7);
                    if (col == 7) {
                        setForeground("Allocated".equals(status) ? AppTheme.SUCCESS :
                                      "Pending".equals(status) ? AppTheme.WARNING : AppTheme.GRAY);
                        setFont(AppTheme.FONT_TABLE_HEAD);
                    } else {
                        setForeground(AppTheme.TEXT_PRIMARY);
                        setFont(AppTheme.FONT_TABLE_BODY);
                    }
                }
                return this;
            }
        });
        int[] widths = {90, 160, 75, 130, 55, 120, 100, 90};
        for (int i = 0; i < widths.length; i++)
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
    }

    public void refresh() {
        tableModel.setRowCount(0);
        for (Student s : DataManager.getInstance().getStudents()) {
            tableModel.addRow(new Object[]{
                s.getStudentId(), s.getName(), s.getGender(), s.getCourse(),
                s.getYear(), s.getPhone(), s.getRoomNumber(), s.getStatus()
            });
        }
    }

    private void filterTable() {
        String q = searchField.getText().trim().toLowerCase();
        tableModel.setRowCount(0);
        for (Student s : DataManager.getInstance().getStudents()) {
            if (s.getStudentId().toLowerCase().contains(q) ||
                s.getName().toLowerCase().contains(q) ||
                s.getCourse().toLowerCase().contains(q) ||
                s.getGender().toLowerCase().contains(q)) {
                tableModel.addRow(new Object[]{
                    s.getStudentId(), s.getName(), s.getGender(), s.getCourse(),
                    s.getYear(), s.getPhone(), s.getRoomNumber(), s.getStatus()
                });
            }
        }
    }

    private Student getSelectedStudent() {
        int row = table.getSelectedRow();
        if (row == -1) { JOptionPane.showMessageDialog(this, "Please select a student first.", "No Selection", JOptionPane.WARNING_MESSAGE); return null; }
        String id = (String) tableModel.getValueAt(row, 0);
        return DataManager.getInstance().getStudentById(id);
    }

    private void editSelected() {
        Student s = getSelectedStudent();
        if (s != null) showStudentDialog(s);
    }

    private void deleteSelected() {
        Student s = getSelectedStudent();
        if (s == null) return;
        int res = JOptionPane.showConfirmDialog(this,
            "Delete student " + s.getName() + "? This will also deallocate their room.",
            "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (res == JOptionPane.YES_OPTION) {
            DataManager.getInstance().deleteStudent(s.getStudentId());
            refresh();
        }
    }

    private void deallocateSelected() {
        Student s = getSelectedStudent();
        if (s == null) return;
        if (s.getRoomNumber().equals("Not Allocated")) {
            JOptionPane.showMessageDialog(this, "Student has no room allocated.", "Info", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        int res = JOptionPane.showConfirmDialog(this,
            "Deallocate room " + s.getRoomNumber() + " from " + s.getName() + "?",
            "Confirm Deallocation", JOptionPane.YES_NO_OPTION);
        if (res == JOptionPane.YES_OPTION) {
            String result = DataManager.getInstance().deallocateRoom(s.getStudentId());
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(this, "Room deallocated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, result, "Error", JOptionPane.ERROR_MESSAGE);
            }
            refresh();
        }
    }

    private void showStudentDialog(Student existing) {
        boolean isEdit = existing != null;
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this),
            isEdit ? "Edit Student" : "Add New Student", true);
        dialog.setSize(460, 520);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());

        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setLayout(new GridBagLayout());
        panel.setBorder(new EmptyBorder(24, 32, 24, 32));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 0, 6, 0);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        JLabel dlgTitle = new JLabel(isEdit ? "Edit Student Details" : "Register New Student");
        dlgTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        dlgTitle.setForeground(AppTheme.PRIMARY);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(dlgTitle, gbc);
        gbc.gridwidth = 1;

        String[] labels = {"Student ID", "Full Name", "Email", "Phone", "Course"};
        JTextField[] fields = new JTextField[labels.length];
        for (int i = 0; i < labels.length; i++) {
            JLabel lbl = new JLabel(labels[i]);
            lbl.setFont(AppTheme.FONT_HEADER);
            lbl.setForeground(AppTheme.TEXT_PRIMARY);
            gbc.gridx = 0; gbc.gridy = i + 1; gbc.gridwidth = 2;
            panel.add(lbl, gbc);
            fields[i] = new JTextField();
            fields[i].setFont(AppTheme.FONT_BODY);
            fields[i].setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(AppTheme.BORDER),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));
            fields[i].setPreferredSize(new Dimension(0, 38));
            gbc.gridy = i + 2; i++;
            // Fix: place field below label
        }

        // Redo layout cleanly
        panel.removeAll();
        panel.setLayout(new GridBagLayout());
        gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 0, 4, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridx=0; gbc.gridy=0; gbc.gridwidth=4;
        panel.add(dlgTitle, gbc);

        String[] lbs = {"Student ID", "Full Name", "Email", "Phone", "Course"};
        JTextField[] flds = new JTextField[lbs.length];
        for (int i = 0; i < lbs.length; i++) {
            JLabel l = new JLabel(lbs[i]);
            l.setFont(AppTheme.FONT_HEADER);
            l.setForeground(AppTheme.TEXT_SECONDARY);
            gbc.gridy = 1 + i*2; gbc.gridwidth=4; gbc.insets = new Insets(8, 0, 2, 0);
            panel.add(l, gbc);
            flds[i] = new JTextField();
            flds[i].setFont(AppTheme.FONT_BODY);
            flds[i].setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(AppTheme.BORDER),
                BorderFactory.createEmptyBorder(6, 10, 6, 10)));
            flds[i].setPreferredSize(new Dimension(0, 38));
            gbc.gridy = 2 + i*2; gbc.insets = new Insets(0, 0, 4, 0);
            panel.add(flds[i], gbc);
        }

        // Year + Gender in one row
        JLabel yrLbl = new JLabel("Year");
        yrLbl.setFont(AppTheme.FONT_HEADER); yrLbl.setForeground(AppTheme.TEXT_SECONDARY);
        gbc.gridy=11; gbc.gridwidth=2; gbc.insets=new Insets(8,0,2,8);
        panel.add(yrLbl, gbc);
        JLabel gnLbl = new JLabel("Gender");
        gnLbl.setFont(AppTheme.FONT_HEADER); gnLbl.setForeground(AppTheme.TEXT_SECONDARY);
        gbc.gridx=2; gbc.insets=new Insets(8,0,2,0);
        panel.add(gnLbl, gbc);

        gbc.gridx=0; gbc.gridy=12; gbc.gridwidth=2; gbc.insets=new Insets(0,0,4,8);
        JComboBox<Integer> yearBox = new JComboBox<>(new Integer[]{1,2,3,4,5});
        yearBox.setFont(AppTheme.FONT_BODY);
        panel.add(yearBox, gbc);

        gbc.gridx=2; gbc.insets=new Insets(0,0,4,0);
        JComboBox<String> genderBox = new JComboBox<>(new String[]{"Male","Female"});
        genderBox.setFont(AppTheme.FONT_BODY);
        panel.add(genderBox, gbc);

        // Fill existing data
        if (isEdit) {
            flds[0].setText(existing.getStudentId()); flds[0].setEditable(false); flds[0].setBackground(new Color(240,240,240));
            flds[1].setText(existing.getName());
            flds[2].setText(existing.getEmail());
            flds[3].setText(existing.getPhone());
            flds[4].setText(existing.getCourse());
            yearBox.setSelectedItem(existing.getYear());
            genderBox.setSelectedItem(existing.getGender());
        } else {
            flds[0].setText(DataManager.getInstance().generateStudentId());
            flds[0].setEditable(false); flds[0].setBackground(new Color(240,240,240));
        }

        // Buttons
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new EmptyBorder(12, 24, 16, 24));
        JButton cancel = makeBtn("Cancel", AppTheme.GRAY);
        cancel.setPreferredSize(new Dimension(100, 38));
        JButton save = makeBtn(isEdit ? "Save Changes" : "Add Student", AppTheme.SUCCESS);
        save.setPreferredSize(new Dimension(140, 38));

        cancel.addActionListener(e -> dialog.dispose());
        save.addActionListener(e -> {
            String id   = flds[0].getText().trim();
            String name = flds[1].getText().trim();
            String email= flds[2].getText().trim();
            String phone= flds[3].getText().trim();
            String course=flds[4].getText().trim();
            int year = (int) yearBox.getSelectedItem();
            String gender = (String) genderBox.getSelectedItem();

            if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || course.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please fill all fields.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Student s = new Student(id, name, email, phone, course, year, gender);
            if (isEdit) {
                s.setRoomNumber(existing.getRoomNumber());
                s.setAllocationDate(existing.getAllocationDate());
                s.setStatus(existing.getStatus());
                DataManager.getInstance().updateStudent(s);
            } else {
                if (!DataManager.getInstance().addStudent(s))
                    JOptionPane.showMessageDialog(dialog, "Student ID already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                else dialog.dispose();
            }
            refresh(); dialog.dispose();
        });

        btnRow.add(cancel); btnRow.add(save);

        JScrollPane sp = new JScrollPane(panel);
        sp.setBorder(null);
        dialog.add(sp, BorderLayout.CENTER);
        dialog.add(btnRow, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private JButton makeBtn(String text, Color color) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? color.brighter() : color);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.setColor(Color.WHITE);
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(getText(), (getWidth()-fm.stringWidth(getText()))/2,
                    (getHeight()+fm.getAscent()-fm.getDescent())/2);
            }
        };
        btn.setFont(AppTheme.FONT_BUTTON);
        btn.setContentAreaFilled(false); btn.setBorderPainted(false);
        btn.setFocusPainted(false); btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(140, 38));
        return btn;
    }
}
